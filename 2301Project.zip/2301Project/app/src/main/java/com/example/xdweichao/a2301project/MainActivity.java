package com.example.xdweichao.a2301project;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;


public class MainActivity extends AppCompatActivity {

    // declaring global variable (objects)
    EditText userET, pwET;
    Button loginET;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //defining screen's object
        userET= (EditText) findViewById(R.id.userET);
        pwET= (EditText) findViewById(R.id.pwET);

        //setting up to listener to the button
        loginET= (Button) findViewById(R.id.loginET);

        loginET.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            //reading inputs
                String username = userET.getText().toString();
                String password = pwET.getText().toString();

                //validating the inputs
                //username: no blank and length of 6
                //password: no blank and length of 8

                if (!username.isEmpty() && username.length()==6){
                    if (!password.isEmpty() && password.length()==6){
                        try{
                            //reading the csv file and storing
                            //each line of the file into an arry
                            //1. filename
                            String filename= "idpwd.csv";

                            //2. Open the file for reading by creating an object of the class
                            //InputStreamerReader
                            InputStreamReader isr= new InputStreamReader(getAssets().open(filename));

                            //3. create a buff object to handle each line of the file
                                BufferedReader reader = new BufferedReader(isr);

                            //4. reading each line of the csb file until
                            String recordline = "";
                            boolean foundmatch = false;
                            while ((recordline = reader.readLine())!= null){
                                //storing each line into an array, first, let's separate each
                                // element of the line by the comma
                                //which create an array
                                String recordArray[] = recordline.split (",");
                                //1st element of the array: username
                                //2nd element of the array: password
                                //checking if the input pair(username,password) match with csv
                                // pair in the array
                                if(username.matches(recordArray[0]) && password.matches(recordArray[1])){
                                    foundmatch = true;
                                    break;
                                }
                            }
                            if(foundmatch == true)
                                Toast.makeText(MainActivity.this, "Welcome, " + password, Toast.LENGTH_LONG).show();
                            else
                                Toast.makeText(MainActivity.this, username + password, Toast.LENGTH_LONG).show();
                                //Toast.makeText(MainActivity.this, "Sorry, invalid username and/or password", Toast.LENGTH_LONG).show();
                        }catch (Exception e){}

                    } else{
                        Toast.makeText(MainActivity.this,"Not Found in Database: Invalid Password", Toast.LENGTH_LONG).show();

                    }
                }else {
                    Toast.makeText(MainActivity.this,"Not Found in Database: Invalid Username", Toast.LENGTH_LONG).show();
                }

            }
        });



    }
}
